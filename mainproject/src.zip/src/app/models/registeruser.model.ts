export class RegisterUser {
    firstName:any;
    lastName:any;
    email:any;
    password:any;
    token:any;
    userId:any;
    dob:any;
    role:any;
}